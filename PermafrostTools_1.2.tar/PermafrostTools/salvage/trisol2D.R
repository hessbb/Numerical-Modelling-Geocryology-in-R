#+
# NAME:
#   TRISOL_2D
#
# PURPOSE:
#	Simultaneously solves N tri-diagonal matrix equations of Z
#	elements using the Thomas algorithm
#
# CATEGORY:
#	utils: math		
#
# CALLING SEQUENCE:
#	trisol2D(a, b, c, d)
#
# INPUTS:
#   A  Lower  diagonal term [N,Z], Note: A[*,0]=0
#   B  Center diagonal term [N,Z]
#   C  Upper  diagonal term [N,Z], Note: C[*.Z-1]=0
#   D  right-hand side (on input) / solution (on output) [N,Z]
#
#   Z  Dimension of the systems of equations (discretizations in heat
#      conduction)  (columns in R)
#   N  The number of systems/pixels (rows in R)
#
# OPTIONAL INPUTS: 
#	None
#
# OUTPUTS:
#	pointer d contains the result (in case of heat conduction this is
#	the new temperature)
#
# COMMON BLOCKS: 
#	None
#
# SIDE EFFECTS:              
#
# RESTRICTIONS: 
#	None
#
# PROCEDURE:
#	This Procedure....
#
# EXAMPLE:
#	TRISOL_2D, m, a, b, c, d, group = group
#
# MODIFICATION HISTORY:
#   SEP, 2005   created by S. Gruber
#   Feb. 2014   ported to R, S. Gruber	
#-
#----------------------------------------------------------------------------
trisol2D <- function(a, b, c, d) {       
  #test data type
  valid <- is.matrix(a) * is.matrix(b) * is.matrix(c) * is.matrix(d)
  valid <- valid * is.numeric(a) * is.numeric(b) * is.numeric(c) * is.numeric(d)
  if (valid != 1) stop("All input must be numeric matrices")
  	
  #number of rows (corresponding to independent systems/pixels) 
  m = nrow(a)

  # ESTABLISH UPPER TRIANGULAR MATRIX 
  for (i in 2:m) { #loop over z-discretizations
    r       <- a[ , i]     / b[ , i-1]
    b[ , i] <- b[ , i] - r * c[ , i-1]
    d[ , i] <- d[ , i] - r * d[*, i-1]
  }  

  ## BACK SUBSTITUTION
  ##---------------------------------------------------
  d[ , m-1] <- d[ , m-1] / b[ , m-1]
  for (i in 2:m) {  #loop over z-discretizations
    j <- m - i - 1
   d[ , j] <- (d[ , j] - c[ , j] * d[ , j+1]) / b[ , j]
  }  
  
  return(d)
}