# TODO: Add comment
# 
# Author: sgubler
###############################################################################
f.declination <- function(Jday, year){
w          <- 360/365.25
J0	       <- 78.801 + 0.2422*(year - 1969) - floor(0.25*(year-1969))
t          <- Jday - 0.5 - J0
dayang.deg <- w*t
DRADEG     <- 180/pi


dayang.rad <- dayang.deg/DRADEG



###*** Declination: Bourgues, 1985
delta.deg <- (0.3723 + 23.2567*sin(dayang.rad) 
			- 0.758*cos(dayang.rad) + 0.1149*sin(2*dayang.rad) + 0.3656*cos(2*dayang.rad) 
			- 0.1712*sin(3*dayang.rad) + 0.0201*cos(3*dayang.rad))

delta.rad <- delta.deg/DRADEG

return(delta.rad)
}
