# TODO: Add comment
# 
# Author: lboeckli
#
# PURPOSE:
#	Calculate potential short-wave solar radiation at the point
#	meteo station for an instant time interval. Wihtout atmosphere
#
# CALLING SEQUENCE:
#	f.met_prad(date.pos = date.pos,julianday = julianday, 
#	metelev, methor, lat, lon, slope,aspect,timezone, int = int)
#
# INPUTS:
#	date.pos	
#	julian:    	date/time of calculation of radiation
#   methor:    horizon-vector of meteo station
#   lat, lon:  latitude/longitude of meteo station in decimal degrees
#	slope, aspect
#   timezone:  timezone of meteostation
#
# KEYWORD PARAMETERS:
#   int:    time interval in hours, default ist 1 day (24h)
#   group:  group of dialog messages or child widgets (heritable)
#
# OUTPUTS:
#	Mean short-wave radiation in W/m2 for given time interval
#
# BACKGROUND:
#	This Function is based on the IDL algorithms of solar geometry and 
#   atmospheric transmittance provided by Javier Corrupio
#
# SIDE EFFECTS:
#   calls functions solarpos and  (atmostrans)
#
#----------------------------------------------------------------------------


### COMMENT: works well compared to solarpos from internet, but not solarpos from tebal
### comparison: solarpos internet and tebal required!!!!
f.met_prad_lb <- function(
		date.pos,
		julianday, 
		methor, 
		lat, 
		lon,
		slope,
		aspect, 
		timezone, 
		int = 24){
	

#julianday starts (counting seconds) from 1.1.1970
	
#intitials and constants
prad <- 0.0                #initial
O3 <- 1.2                  #dobson units
visibility <- 60           #km, always, no matter what


#convert slope and azimuth into surface normal vector
DRADEG <-180/pi
razimuth <- aspect / DRADEG
elevation <- (90-(slope))/DRADEG 
CellVector    <- vector()
CellVector[1] <- sin(razimuth)*cos(elevation)   #**positive eastwards
CellVector[2] <- -cos(razimuth)*cos(elevation)   #**positive southwards
CellVector[3] <- sin(elevation)

#calculate time steps
jnow      <- julianday #- 0.0156250

year      <- as.numeric(format(date.pos,format="%Y"))
mon       <- as.numeric(format(date.pos,format="%m"))    
day       <- as.numeric(format(date.pos,format="%d"))	
date0     <- paste(day,".", mon,".",year," 00:00:00",sep="")
strpday0  <- strptime(date0, "%d.%m.%Y  %H:%M:%S")
julianday0<- as.numeric(julian(strpday0))
j0        <- julianday0   #substract 22.5 min in day fractions




#handle dates
firstjan.now    <- paste("01.01.",year,"00:00:00",sep="")
firstjan.now.st <- strptime(firstjan.now, "%d.%m.%Y  %H:%M:%S")
doynow          <- floor(jnow - (as.numeric(julian(firstjan.now.st))))+1

time <- (jnow - j0)*24   # current time in hours, decimal
time <- ifelse(time < 0, 24 + time, time)

#calc sundata and solpos for current timestep (of interval)
sundata    <- data.frame(
		Jday = doynow,
		year = year,
		time = time,
		latitude =  lat, 
		longitude = lon,
		timezone = timezone)
		
solpos <- f.solarpos(sundata,limb=F, twilight=F)


#calc radiation if sun above horizon
if(solpos$elevation > 0){

#calc horizon in direction of sun (for point, meteo station)
hele <-  approx(methor[,1], (methor)[,2], solpos$azimuth)

#horizon shading
log.shade <- solpos$elevation >= hele$y
shade <- ifelse(log.shade == FALSE,  0, 1)
#compute direct irradiance

zenith   <-  90.0-solpos$elevation

#insol    <-  f.TB_AtmosTrans(zenith, doynow, height = metelev, visibility, rh, airt, O3)
# Atmosphäre ist ausgeschaltet
insol=1367.0*0.9751

#sun-terrain geometry
cosangle <- c(CellVector[1]*solpos$vector[1] +
		CellVector[2]*solpos$vector[2] +
		CellVector[3]*solpos$vector[3])
cosangle <- (cosangle > 0) * cosangle   #self shading condition
#add current prad to cum prad
prad <- prad + shade * cosangle * insol
}

prad <- prad

prad 

}
