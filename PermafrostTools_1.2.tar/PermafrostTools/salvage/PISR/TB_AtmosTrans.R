# TODO: Add comment
# 
# Author: sgubler
###############################################################################

#   TEBAL Version 1.0                                 by DS/RSL
# -----------------------------------------------------------------
# 
#    $Id: tb_atmostrans.pro,v 1.2 2005/09/09 11:32:54 idl_stgruber Exp $
#    $Log: tb_atmostrans.pro,v $
#    Revision 1.2  2005/09/09 11:32:54  idl_stgruber
#    minor change
#
#
#+
# NAME:
#	TB_ATMOSTRANS
#
# FUNCTION ATMOSTRANS CHANGED FROM THE ORIGINAL VERSION OF J. CORRIPIO
#  -> diffuse radiation component has been removed
#
# Copyright (c) 2001 Javier G Corripio.  
#  			jgc@geo.ed.ac.uk 
#
# PURPOSE:
#	Computes direct & diffuse solar irradiance for clear skies
#
# CATEGORY:
#	Solar Radiation
#	Atmospheric Sciences
#
# CALLING SEQUENCE:
#	result = AtmosTrans(zenith,[day,height,visibility,RH,TempK,O3,alphag,TAU=tau,verbose=verbose])
#
# INPUTS:
#	zenith: solar zenithal angle 
#		(relative to horizontal surface) (REF:1)
#	day: day of the year (1 : 365) 
#	height: elevation above sea level
#	visibility: in Km, for aerosol attenuation (5 < vis < 180 Km)
#		aerosol alternatives to be implemented
#	RH: relative humidity (0:100)%
#	TempK: temperature, degrees Kelvin
#	O3: ozone layer thickness in cm (from REF:2, see notes)
# 	
# KEYWORDS:
#	MS: float variable. !!!!!!!!!!! CHECK !!!!!!!!!!!!!
#		set this value to ground albedo (0.0 to 1.0)
#		to compute multiple scattering between ground and Sky
#	TAU: named structure.  Will contain individual transmittances due to:
#		tauR: Rayleigh scattering
#		tauG: uniformly mixed gases other that water vapour
#		tauW: water vapour
#		tauO: ozone
#		tauA: aerosols
#
# OUTPUTS:	
#	Result: 2-dimensional array  [In, Id]
#		In: direct irradiance normal to surface
#		Id: diffusse irradiance
#
# SUBROUTINES:
#
# REQUIREMENTS:
#	FUNCTION wvapsat	
#
# NOTES:
#	1) 1 Dobson Unit (DU) is defined to be 0.01 mm thickness at stp.
#
# COMMENTS:
#	If no optional parameters are given, it computes irradiance at 
#	sea level and standard atmosphere
#
# REFERENCES:
#
## REF:1
## http://www.dict.org/bin/Dict?Form=Dict2&Database=devils&Query=ZENITH
##
## REF:2
## TOMS/EP Total Ozone Mapping Spectrometer / Earth Probe
## http://toms.gsfc.nasa.gov/ozone/ozone.html
##
## Spencer, J. W.: 1971, Fourier series representation of the position of 
## the sun, Search 2, 172.
##
## REFERENCES FOR COMPUTATION: link to URL (too many)Iqbal83 ParMod C
#
#
# EXAMPLE:
#	Insol = AtmosTrans()
#	print,insol to do.....
#	
#
# MODIFICATION HISTORY:
#	JGC, 6 November, 2001 
#	
#-
		
		
f.TB_AtmosTrans <- function(zenith,day,height,visibility,rh,airt,O3){

#make error if zenith is too big
#if(zenith > 90) return(0.0) 


#----- PARAMETERS & Variables ------------------------------------------------
stlapse   <- -0.0065	    # standard lapse rate K/m
radeg     <- 180.0/pi	    # radianes to degrees double precission
Theta     <- zenith/radeg	# solar zenith angle radians
Isc       <- 1367.0	        # solar constant (Wm^(-2))
ssctalb   <- 0.9	        # single scattering albedo (aerosols)(Iqbal, 1983)
Fc        <- 0.84	        # ratio of forward to total energy scattered (Iqbal, 1983)
REarth    <- 6.3756766e6    # Average earth's radius (m)
Md        <- 28.966 	    # Molecular weight of dry air
atmos_P0  <- 1.013250e5	    #Standard sea-level atmospheric pressure Pa
atmos_T0  <- 0288.15	    #Standard sea-level Temperature
atmos_R   <- 8.31432 	    #Universal gas constant (J deg-1 kmol-1)
earth_G   <- 9.80665 	    #Acceleration due to gravity (m s-2)
# alpha_atmos	# atmospheric albedo
# alphag	# ground albedo
# In 		# direct normal irradiance (Wm^(-2))
# Id		# total diffuse irradiance on a horizontal surface(Wm^(-2))
# Idr		# diffuse irradiance on a h.s.-> molecular scattering (Wm^(-2))
# Ida		# diffuse irradiance on a h.s.-> aerosols (Wm^(-2))
# Idm		# diffuse irradiance on a h.s.-> multiplescattering (Wm^(-2))
# Mr		# relative optical air mass
# Ma		# relative optical air mass pressure corrected
# Pz 		# pressure at height z
# zenith 	# solar zenith angle degrees
# wvap_s	# saturated vapour pressure (Leckner, 1978)
# Wprec 	# precipitable water (Leckner, 1978)
# airt		# temperature in Kelvin
#------------------------------------------------------------------------------
		
		
# removed checking
		
#------ ATMOSPHERIC PARAMETERS---------------------------------------------
		
#*** pressure as a function of altitude US standard atmosphere
H1 <- (REarth * height) /(REarth + height) 
HB <- 0.0


Pz <- atmos_P0*(atmos_T0/(atmos_T0+stlapse*(H1-HB)) )^( (earth_G*Md)/(atmos_R*stlapse*1000) )
Pz <- Pz/100.0 	#Pa top mb
	
#** relative optical air mass
		
Mr <- 1.0/(cos(Theta)+0.15*((93.885-zenith)^(-1.253))) 
		
Ma <- Mr*Pz/1013.25

#** Use Lowe(1977) 
wvap_s <-  f.wVapSat(airt)
	
#a0 = DOUBLE(6984.505294)	#Lowe's polynomials for vapor pressure
#a1 = DOUBLE(-188.9039310)
#a2 = DOUBLE(2.133357675)	#**********************************
#a3 = DOUBLE(-1.288580973e-2)	#later use call to function /water /ice
#a4 = DOUBLE(4.393587233e-5)	#so it's common for heatflux, tau, longwav
#a5 = DOUBLE(-8.023923082e-8)
#a6 = DOUBLE(6.136820929e-11)
		
#wvap_s = a0+airt*(a1+airt*(a2+airt*(a3+airt*(a4+airt*(a5+a6*airt)))))
Wprec <- 0.493*(rh/100.0)*wvap_s/airt		# in cm Leckner (1978)
		
		
#------- SUN EARTH DISTANCE: Spencer(1971) ---------------------------------
#eccentricity correction
dayang_S <- 2.0*pi*(day-1)/365.0
rho2 <- 1.00011 + 
		0.034221*cos(dayang_S)+0.00128*sin(dayang_S)+ 
		0.000719*cos(2*dayang_S)+0.000077*sin(2*dayang_S)
		
#--------------- DIRECT IRRADIANCE ------------------------------------------
		
TauR <- exp((-.09030*(Ma^0.84) )*(1.0+Ma-(Ma^1.01)) )
		
TauO <- 1.0-( ( 0.1611*(O3*Mr)*(1.0+139.48*(O3*Mr))^(-0.3035) ) - 0.002715*(O3*Mr)*( 1.0+0.044*(O3*Mr)+0.0003*(O3*Mr)^2 )^(-1))
		
TauG <- exp(-0.0127*(Ma^0.26))
		
TauW <- 1.0-2.4959*(Wprec*Mr)*( (1.0+79.034*(Wprec*Mr))^0.6828 + 6.385*(Wprec*Mr) )^(-1)
#** Wprec is pressure & temperature corrected, 
#** Mr need not to be correcred (Iqbal83, p. 176)
		
TauA <- ( 0.97-1.265*(visibility^(-0.66)) )^(Ma^0.9)   #M?chler, 1983 
#** uses parameterization model A (visibility) (iqbal83)
		
TauTotal <- TauR*TauO*TauG*TauW*TauA
		
In <- 0.9751*rho2*Isc*TauTotal
		
#--------------- DIFUSSE IRRADIANCE ------------------------------------------
		
In	
}

