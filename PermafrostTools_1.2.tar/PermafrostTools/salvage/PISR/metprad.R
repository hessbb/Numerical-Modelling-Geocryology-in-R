# TODO: Add comment
# 
# Author: sgubler
###############################################################################


#    TEBAL
# -----------------------------------------------------------------
#
#    $Id: tb_metprad.pro,v 1.10 2005/11/14 10:01:21 idl_jnoetzli Exp $
#    $Log: tb_metprad.pro,v $
#    Revision 1.10  2005/11/14 10:01:21  idl_jnoetzli
#    updateCVS: ----------------------------------------------------------------------
#
#    Revision 1.9  2005/10/26 08:05:06  idl_jnoetzli
#    corrections
#
#    Revision 1.8  2005/10/21 18:15:48  idl_jnoetzli
#    update
#
#    Revision 1.7  2005/09/06 09:29:03  idl_jnoetzli
#    Jeannettes changes for differing time steps
#
#    Revision 1.6  2005/03/03 13:56:29  idl_stgruber
#    new version 2005
#
#    Revision 1.5  2004/06/15 22:40:26  idl_stgruber
#    changed potential sw calc
#
#    Revision 1.4  2004/06/15 15:46:10  idl_stgruber
#    minor
#
#    Revision 1.3  2004/06/15 05:45:54  idl_stgruber
#    initial
#
#    Revision 1.2  2004/06/07 12:42:05  idl_stgruber
#    test
#
#    Revision 1.1  2004/06/07 12:34:16  idl_stgruber
#    initial
#
#+
# NAME:
#	TB_METPRA
#
# PURPOSE:
#	Calculate potential short-wave solar radiation at the driving
#	meteo station for an instant or a mean for a time interval.
#
# CATEGORY:
#	TEBAL
#
# CALLING SEQUENCE:
#	vec = TB_METPRAD (julian, metelev, airt, methor, lat, lon,
#	timezone, int = int, group = group)
#
# INPUTS:
#	julian:    date/time of calculation of radiation
#   metelev:   elevation of meteo station
#   airt:      air temperature
#   methor:    horizon-vector of meteo station
#   lat, lon:  latitude/longitude of meteo station in decimal degrees
#   timezone:  timezone of meteostation
#
# KEYWORD PARAMETERS:
#   int:    time interval in hours, default ist 1 day (24h)
#   group:  group of dialog messages or child widgets (heritable)
#
# OUTPUTS:
#	Mean short-wave radiation in W/m2 for given time interval
#
# BACKGROUND:
#	This Function is based on the IDL algorithms of solar geometry and 
#   atmospheric transmittance provided by Javier Corrupio
#
# SIDE EFFECTS:
#   calls functions solarpos and  atmostrans
#
# EXAMPLE:
#   Result = FUNCTION_NAME (Parm1, Parm2)
#
# MODIFICATION HISTORY:
#   Aug 2002, created by Stephan Gruber
#   Aug 2005, Jeannette Noetzli, flexible time interval added
#-
#----------------------------------------------------------------------------


### COMMENT: works well compared to solarpos from internet, but not solarpos from tebal
### comparison: solarpos internet and tebal required!!!!
f.met_prad <- function(
		date.pos,
		julianday, 
		metelev, 
		airt, 
		rh, 
		methor, 
		lat, 
		lon,
		slope,
		aspect, 
		timezone, 
		int = 24){
	

#julianday starts (counting seconds) from 1.1.1970
	
#intitials and constants
prad <- 0.0                #initial
O3 <- 1.2                  #dobson units
visibility <- 60           #km, always, no matter what


#convert slope and azimuth into surface normal vector
DRADEG <-180/pi
razimuth <- aspect / DRADEG
elevation <- (90-(slope))/DRADEG 
CellVector    <- vector()
CellVector[1] <- sin(razimuth)*cos(elevation)   #**positive eastwards
CellVector[2] <- -cos(razimuth)*cos(elevation)   #**positive southwards
CellVector[3] <- sin(elevation)

#calculate time steps
jnow      <- julianday #- 0.0156250

year      <- as.numeric(format(date.pos,format="%Y"))
mon       <- as.numeric(format(date.pos,format="%m"))    
day       <- as.numeric(format(date.pos,format="%d"))	
date0     <- paste(day,".", mon,".",year," 00:00:00",sep="")
strpday0  <- strptime(date0, "%d.%m.%Y  %H:%M:%S")
julianday0<- as.numeric(julian(strpday0))
j0        <- julianday0   #substract 22.5 min in day fractions




#handle dates
firstjan.now    <- paste("01.01.",year,"00:00:00",sep="")
firstjan.now.st <- strptime(firstjan.now, "%d.%m.%Y  %H:%M:%S")
doynow          <- floor(jnow - (as.numeric(julian(firstjan.now.st))))+1

time <- (jnow - j0)*24   # current time in hours, decimal
time <- ifelse(time < 0, 24 + time, time)

#calc sundata and solpos for current timestep (of interval)
sundata    <- data.frame(
		Jday = doynow,
		year = year,
		time = time,
		latitude =  lat, 
		longitude = lon,
		timezone = timezone)
		
solpos <- f.solarpos(sundata,limb=F, twilight=F)


#calc radiation if sun above horizon
if(solpos$elevation > 0){

#calc horizon in direction of sun (for point, meteo station)
hele <-  approx(methor[,1], (methor)[,2], solpos$azimuth)

#horizon shading
log.shade <- solpos$elevation >= hele$y
shade <- ifelse(log.shade == FALSE,  0, 1)
#compute direct irradiance

zenith   <-  90.0-solpos$elevation

#insol    <-  f.TB_AtmosTrans(zenith, doynow, height = metelev, visibility, rh, airt, O3)
insol=1367.0*0.9751



#sun-terrain geometry
cosangle <- c(CellVector[1]*solpos$vector[1] +
		CellVector[2]*solpos$vector[2] +
		CellVector[3]*solpos$vector[3])
cosangle <- (cosangle > 0) * cosangle   #self shading condition
#add current prad to cum prad
prad <- prad + shade * cosangle * insol
}


prad <- prad#/ninc + 0.0000000001

prad 


}
