# TODO: Add comment
# 
# Author: sgubler
###############################################################################


# $Id: wvapsat.pro,v 5.4 
#
# Copyright (c) 2001 Javier G Corripio.  
#  			jgc@geo.ed.ac.uk
#+
# NAME:
#	wVapSat (function)
#
# PURPOSE:
#	computes saturated vapor pressure over water and over ice
#
# CATEGORY:
#	Atmospheric Sciences
#
# CALLING SEQUENCE:
#	result = wVapSat(TempK,[/WATER,/ICE])
#
# INPUTS:
#	 TempK temperature in Kelvin
#
# KEYWORDS
#	WATER: set this keyword to compute aturated vapor pressure over water
#		this is the default
#	ICE: set this keyword to compute aturated vapor pressure over ice
#	
# OUTPUTS:	
# 	
#	saturated vapor pressure in hPa (float)
#
# SUBROUTINES:
#
# REQUIREMENTS:
#	
#
# NOTES:
#	Uses Lowes polynomials
#
# COMMENTS:
#	
#
# REFERENCES:
#
## Lowe, P. R.: 1977, An approximating polynomial for the computation of 
#    saturation vapor pressure, Journal of Applied Meteorology 16, 100-103.
#
# EXAMPLE:
#	
#	
#
# MODIFICATION HISTORY:
#	JGC, 14/11/2001 
#	
#-
		
f.wVapSat <- function(tempK,water=FALSE,ice=FALSE){

#ERROR message IDL	
#IF (n_params() EQ 0) THEN BEGIN
#message, 'USAGE: Result = wVapSat = (TempK,[/WATER,/ICE])',/INFO 
#RETURN,!values.F_NaN
#ENDIF
# IF invalid ranges of Temp.  to implement...

a0 <-  (6984.505294)	#Lowe's polynomials for vapor pressure
a1 <-  (-188.9039310)
a2 <-  (2.133357675)	
a3 <-  (-1.288580973e-2)	
a4 <-  (4.393587233e-5)	
a5 <-  (-8.023923082e-8)
a6 <-  (6.136820929e-11)
		
temp <- tempK
		
if(ice == TRUE){
temp <- tempK - 273.15
a0 <- 6.109177956
a1 <-  (5.03469897e-1)
a2 <-  (1.886013408e-2)
a3 <-  (4.176223716e-4)
a4 <-  (5.824720280e-6)
a5 <-  (4.838803174e-8)
a6 <-  (1.838826904e-10)
}
wvap_sat <- a0+temp*(a1+temp*(a2+temp*(a3+temp*(a4+temp*(a5+temp*a6)))))
		
return(wvap_sat)
		
}
