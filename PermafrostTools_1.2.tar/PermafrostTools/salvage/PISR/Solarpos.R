# TODO: Add comment
# 
# Author: sgubler
###############################################################################

f.solarpos <- function(sundata, limb = F, twilight =F){

	
	
Jday       <- sundata$Jday + (sundata$time/24.)
year       <- sundata$year
delta.rad  <- f.declination(Jday=Jday, year=year)

DRADEG     <- 180/pi
### Computes equation of time according to Spencer(1971).

daynumberS <- 2 * pi * (Jday - 1)/365
EqTime     <-  0.000075 + 
			   0.001868*cos(daynumberS)   - 0.032077*sin(daynumberS) - 	
  			   0.014615*cos(2*daynumberS) - 0.040849*sin(2*daynumberS)
	   
EqTime.hour  <-  EqTime * 12/pi   ### EqTime in hours
### hour_angle (omega):
longitude     <-  sundata$longitude
stndmeridian  <-  sundata$timezone*15
deltaLongTime <-  longitude-stndmeridian  ###angle to time zone
deltaLongTime <-  deltaLongTime * 24/360. ### angle to hours

omega         <- pi * ( ( (sundata$time+deltaLongTime+EqTime.hour)/12 ) - 1)

lat           <- sundata$latitude / DRADEG 

SunVector     <- c(-sin(omega)*cos(delta.rad ),
				sin(lat)*cos(omega)*cos(delta.rad)-cos(lat)*sin(delta.rad),# sun elevation angle
				cos(lat)*cos(omega)*cos(delta.rad )+sin(lat)*sin(delta.rad))


### Solar elevation:
elevation <-  asin(SunVector[3]) * DRADEG

### Solar azimuth
		
azimuth <- ifelse((SunVector[1] == 0) && (SunVector[2] == 0), 
		0.0,
		( pi - atan2(SunVector[1],SunVector[2]) ) *  DRADEG)

### Sunrise and sunset
omeganul   <-  acos(-tan(lat)*tan(delta.rad)) ###Local Solar Time

if(limb ==T){ 
omeganul <- omeganul+((.5*100.0/60.0)/DRADEG)
}
sunrise  <- 12*(1-omeganul/pi)-deltaLongTime-EqTime.hour # **back to official time
sunset   <-  12*(1+omeganul/pi)-deltaLongTime-EqTime.hour
#print(omeganul)

if(twilight == T){ 
sixbelowh <- cos(96.0/DRADEG)
omega_6   <- acos((sixbelowh - sin(lat)*sin(delta.rad))/(cos(lat)*cos(delta.rad)))
srtwt = 12*(1-omega_6/pi)-deltaLongTime-EqTime.hour # **back to official time
sstwt = 12*(1+omega_6/pi)-deltaLongTime-EqTime.hour
twilight = c(srtwt,sstwt)
}

declination <-  delta.rad * DRADEG

solpos      <- list(
		'vector'=SunVector,
		'azimuth'=azimuth,
		'elevation'=elevation,
		'declination'=declination,
		'sunrise'=sunrise,
		'sunset'=sunset,
		'EqTime'=EqTime.hour,
		'omega'=omega,
		'twilight'=twilight)

}

