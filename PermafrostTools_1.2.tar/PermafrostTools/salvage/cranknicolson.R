# NAME:
#	CRANKNICOLSON
#
# PURPOSE:
#   1-dimensional finite-difference (crank-nicolson) heat conduction
#	scheme that operates on variable depth-discretization. The lower
#	boundary condition is given as a heat flux and the upper boundary
#	condition can be specified either as a heat flux of as a surface
#	temperature together with a heat transfer coefficient.
#
# CATEGORY:
#	phys		
#	
# CALLING SEQUENCE:
#	CRANKNICOLSON
#
# INPUTS:
#   dt  Time step [s]
#   Zj  Z-levels increasing upwards [m] (N,Z)
#   Tj  Temperature              [K or C]    (N,Z)
#   Cj  Volumetric heat capacity [J m-3 K-1] (N,Z) 
#   Kj  Thermal conductivity     [W m-1 K-1] (N,Z)
#   Gj  Volumetric heat source   [W]         (N,Z)
#       (ignored for boundary nodes!)
#   NLS max number of snow layers
#   BCL Lower boundary condition as 
#               - qg [W m-2] (N)
#   BCU Upper boundary condition either as 
#               - qg [W m-2]  (N) or 
#               - t0 [C or K] (N)
#   BCNODE number of boundary condition node
#
# OPTIONAL INPUTS: 
#	None
#	
# KEYWORD PARAMETERS:
#   group:     group of dialog messages or child widgets (heritable)
#
# OUTPUTS:
#	vector of temperatures [C or K]
#
# COMMON BLOCKS: 
#	None
#
# SIDE EFFECTS:              
#   calls function/procedure : ....
# 
# RESTRICTIONS: 
#	None
#
# BACKGROUND:
#
#
# NOTE ON GEOMETRY
#   Z[*,0] is the surface discretization, z increases upwards and 
#          the sign of numbers is not a problem
#
# NOTE ON SHIFTING ARRAYS IN Z-DIRECTION
#   z i+1 comes from shift(zj, 0,-1)
#   z i-1 comes from shift(zj, 0, 1)
#
# EXAMPLE:
#   CRANKNICOLSON(tj, kj, cj, zj, gj, bcl, bcu, dt
#
# MODIFICATION HISTORY:
#   September, 2005  created by Stephan Gruber, GIUZ
#-
#----------------------------------------------------------------------------
cranknicolson <- function(Tj, kj, cj, gj, zj, dt, bcl, bcu, bcu.node, 
                          bctype = c("DIRICHLET","DIRICHLET")) {
 

 ## ===================================================================
 ## PREPARATION
 
 ## make number of elements suitable for indexing
 m = dimst[1]-1
 n = dimst[0]

 ## put top boundary condition in top node if bcnode is not specified
 IF n_params() lt 9 THEN bcnode = intarr(n)

 ## make arrays for TRISOL_2D
 A = fltarr(n, m+1)
 B = fltarr(n, m+1)
 C = fltarr(n, m+1)
 D = fltarr(n, m+1)


 ## ===================================================================
 ## COMPUTE MATRIX TERMS FROM SUBSTITUTIONS

 #Volumetric heat capacity divided by time step
 cdt <- Cj / dt

 #z-difference of upper and lower node (artificial negative sign) 
 dz2       <- shift(zj, 0, -1) - shift(zj, 0, 1)
 dz2[ , m] <- zj[ ,m] - zj[ ,m-1] #lowest  node
 dz2[ , 0] <- zj[ ,1] - zj[ ,0]   #highest node
 dz2       <- dz2 - (DZ2 EQ  0)       #avoid division by zero (no snow)

 ##mean k over delta-z for upper space
 KDU    = (shift(*Kj,0,1)+(*Kj))/$
          (shift(*Zj,0,1)-(*Zj))/2.0
 KDU[0] = (*Kj)[*, 0]/((*Zj)[*,0]-(*Zj)[*,1])
 zero = where(finite(KDU) EQ 0, czero)  #catch division by zero
 IF czero GT 0 THEN KDU[zero] = 1       #catch division by zero

 #Upper diagonal term [N,Z], Note: C[*,m] fixed for BC
 c = shift(kdu, 0, -1) / dz2

 #Lower diagonal term [N,Z], Note: a[ ,0]=0
 a = kdu / dz2

 #Center diagonal term [N,Z]
 b <- cdt - a - c

 #Right-hand side (on input) [N,Z]
 d <- (cdt + a + c) * (Tj) - #node i,  center diagonal
     c * shift(Tj, 0, -1) -    #node i+1, upper diagonal
     a * shift(Tj, 0,  1) -    #node i-1, lower diagonal
     (Gj) / dz2 * 2            #source term (normalized to W)
                               #(negative because of negative DZ2)


 # ===================================================================
 # LOWER BOUNDARY CONDITION (NEUMANN) ON LAST NODE
 c[ ,m] <- 0.0 
 b[ ,m] <-  cdt[ ,m] - a[ ,m]
 d[ ,m] <- (cdt[ ,m] + a[ ,m]) * (Tj)[ ,m]   -  #node i, center diagonal
                       a[ ,m]  * (Tj)[ ,m-1] +  #node i+1, upper diagonal
           (2.0 * (bcl) + (Gj)[ ,m]) / dz2[ ,m] #boundary condition



 # ===================================================================
 # SURFACE BOUNDARY CONDITION (NEUMANN ON VARIABLE NODE)
 IF keyword_set(bcu_dirichlet) THEN BEGIN
 #boundary condition dirichlet for model testing
    d[ , 1] <- d[ , 1] - a[ ,1] * (bcu) 
    a[ , 1] <- 0.0
 ENDIF ELSE BEGIN
   nmin = min(*bcnode, max = nmax) #get highest and lowest bc node
   FOR bcn = nmin, nmax DO BEGIN  #loop over bc nodes
     in = where(*bcnode EQ bcn, count)
     IF count GT 0 THEN BEGIN 
       dzn = (*zj)[in,bcn]-(*zj)[in,bcn+1] #distance between boundary node and next one
       dzq = dzn^2.0                       #squared
       A[in,bcn] *= 0.0 
       C[in,bcn]  = -(*Kj)[in,bcn]/dzq
       B[in,bcn]  =  CDT[in,bcn]-C[in,bcn]
       D[in,bcn]  = (CDT[in,bcn]+C[in,bcn])*(*Tj)[in,bcn]  -$ #node i,  center diagonal
                                 C[in,bcn] *(*Tj)[in,bcn+1]+$ #node i+1, upper diagonal
                     2.0*(*BCU)[in]/dzn                       #boundary condition
     ENDIF
   ENDFOR
 ENDELSE

  # ===================================================================
  # Simultaneously solve tridiagonal systems for all n points/pixels
  #   a  Lower  diagonal term [N,Z], Note: a[*,0]=0
  #   b  Center diagonal term [N,Z]
  #   c  Upper  diagonal term [N,Z], Note: c[*,Z-1]=0
  #   d  right-hand side (on input) / solution (on output) [N,Z]
  #   Z  Dimension of the systems of equations (z-nodes)
  #   N  Number of systems/pixels solved simultaneously.
  Tj  <- trisol2D(a, b, c, d)
  return(Tj)
}