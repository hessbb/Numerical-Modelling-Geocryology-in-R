##==== HEADER ================================================
##  This is a collection of tools to handle 
##  ground surface temperature (GST) or rock
##  surface temperature measurements in R and
##  MySQL. Standard routines for the import of
##  data logger text files as well as export of
##  PERMOS .csv files exist.
##
##  Stephan Gruber, Dec. 2009 
##============================================================


#load library
library("RMySQL")

#construct method to concatenate strings with ampersand
"&" <- function(...) UseMethod("&") 
"&.default" <- .Primitive("&") 
"&.character" <- function(...) paste(...,sep="") 


#==== MAKE DB CONNECTION =============================================
gst.db.con <-function() {
	#ask for unsername and password if not given
	print("Enter user name")
	user<-scan(n=1,what=character())
	print("Enter password")
	pwd<-scan(n=1,what=character()) 	
	
	#connect to db server	
	db <- dbConnect(MySQL(), user, pwd, 
			dbname="permos_1", host="permosdata.geo.uzh.ch")
	return(db)
}


	
#==== MAKE DATA TABLE IN DB ==========================================
gst.db.new <-function() {
	#connect to db server
    db <- gst.db.con()
    
    #insert data into main table
    sql_table_new <-"CREATE TABLE `permos`.`rockt_10cm` ("&
  					"`time` DATETIME NOT NULL,"&
  					"`site_ID` CHAR(20) ASCII NOT NULL,"&
  		  			"`temperature` FLOAT NOT NULL,"&
  		  			"`timestamp` TIMESTAMP,"&  
  					"PRIMARY KEY (`time`, `site_ID`))"
    status_table_new <- dbSendQuery(db, sql_table_new)
    
	#disconnect from db server
    dbDisconnect(db)
    }


#==== INSERT DATA INTO DB ============================================
gst.db.insert <-function(data.frame) {
    #prepare data frame with proper labels
    names(data.frame)<-c("time","temperature","site_ID")

	#connect to db server
    db <- gst.db.con()
    
    #drop temporary table if an old one exists
    sql_drop <-	"DROP TABLE IF EXISTS R_temp_table"
    status_drop <- dbSendQuery(db,sql_drop)
    
    #write data into temporary table
    dbWriteTable(db, "R_temp_table", data.frame)

    #insert data into main table
    sql_insert<-"INSERT IGNORE INTO rockt_10cm (time, temperature, site_ID) "&
                "SELECT time, temperature, site_ID FROM R_temp_table"
    status_insert <- dbSendQuery(db,sql_insert)
	
    #drop temporary table	
    status_drop <- dbSendQuery(db,sql_drop)
    
	#disconnect from db server
    dbDisconnect(db)
	}

#==== DELETE DATA FROM DB ============================================
#Example: gst.db.delete("2009-11-14 15:32","2009-11-18 15:32","CH_0031") 
gst.db.delete <-function(tbeg,tend,site_ID) {
	#connect to db server
	db <- gst.db.con()
		
	#query number of rows
	sql_where<-"WHERE site_ID='"&site_ID&"' AND "&
			   "time <= DATE('"&tend&"') AND time >= DATE('"&tbeg&"')"

	sql_select<-"SELECT time, temperature, site_ID FROM rockt_10cm "&sql_where 
	todelete <- dbGetQuery(db, sql_select)
		
	#plot to delete
	time <- strptime(todelete$time, format="%Y-%m-%d %H:%M:%OS") #make proper R time
	plot(time,todelete$temperature,type="l",main="Data selected for deletion, site: "&site_ID)
		
	#ask for confirmation before deleting
	nrow<-length(todelete$temperature)
	title="Delete " & nrow & " rows from " & site_ID & " (YES/NO)?"
	print(title)
	do<-scan(n=1,what=character()) 	
	if (toupper(do) == "YES") {
		#insert data into main table
		sql_delete<-"DELETE FROM rockt_10cm "& sql_where
		status_delete <- dbSendQuery(db,sql_delete)	
	}	
	#disconnect from db server
	dbDisconnect(db)
	}	
	 
#==== GET OVERVIEW FROM DB ============================================
#site_ID, begin, end, number 
gst.db.overview <-function(db) {
		#connect to db server
		db <- gst.db.con()
		
		#query
		sql_select<-"SELECT site_ID, min(time) AS begin,max(time) as end, count(time) as n FROM rockt_10cm GROUP BY site_ID" 
		overview <- dbGetQuery(db, sql_select)
		
		#plot to delete
	    print("Overview of data contained in DB: ")
		print(overview)

		#disconnect from db server
		dbDisconnect(db)
	}
	
	
#=== GET HOURLY, DAILY AND ANNUAL TIME AGGREGATE FROM DB =============
gst.db.aggregate <-function(site_ID,qday,qann) {
	#make quality criteria for aggregate values
	#qann <- 360  #minimum number of full days of measurements per year
	#qday <- 12   #minimum number of full hours of measurements per 
	#             #day (12: UTL measured only every 2h)
	
	#connect to db server
    db <- gst.db.con()     
                       
    #concatenate hourly query string
    QueryString <- "CREATE TEMPORARY TABLE R_temp_table_hour SELECT "&
                   "FROM_UNIXTIME(FLOOR(UNIX_TIMESTAMP(time)/3600)*"&
                   "3600+1800) AS DBtime, COUNT(temperature) AS count, "&
                   "AVG(temperature) AS Tmean,"&
                   "MIN(temperature) as Tmin, MAX(temperature) AS Tmax "&
                   "FROM rockt_10cm WHERE site_ID='"&site_ID&
                   "' GROUP BY FLOOR(UNIX_TIMESTAMP(time)/3600)"
    #send query to execute on db server
    res <- dbSendQuery(db, QueryString)

    #concatenate daily query string
    QueryString <- "CREATE TEMPORARY TABLE R_temp_table_day SELECT "&
                   "FROM_UNIXTIME(FLOOR(UNIX_TIMESTAMP(DBtime)/86400)*"&
                   "86400+43200) AS DBtime, COUNT(Tmean) AS count, "&
                   "AVG(Tmean) AS Tmean, MIN(Tmin) as Tmin, MAX(Tmax) AS Tmax "&
                   "FROM R_temp_table_hour GROUP BY FLOOR(UNIX_TIMESTAMP(DBtime)/86400)"
    #send query to execute on db server
    res <- dbSendQuery(db, QueryString)
	
    #concatenate annual query string
    QueryString <- "CREATE TEMPORARY TABLE R_temp_table_year SELECT "&
                   "year(DBtime) AS year, COUNT(Tmean) AS count, "&
                   "AVG(Tmean) AS Tmean, MIN(Tmin) as Tmin, MAX(Tmax) AS Tmax "&
                   "FROM R_temp_table_day WHERE count >= "&round(qday,0)&
                   " GROUP BY year(DBtime)"
    #send query to execute on db server
    res <- dbSendQuery(db, QueryString)
    
    #get data from db server
    res <- dbSendQuery(db, "SELECT * FROM R_temp_table_hour")
    hour<- fetch(res, n = -1)
    res <- dbSendQuery(db, "SELECT * FROM R_temp_table_day WHERE count >= "&round(qday,0))    
	day <- fetch(res, n = -1)	
    res <- dbSendQuery(db, "SELECT * FROM R_temp_table_year WHERE count >= "&round(qann,0))  
	year<- fetch(res, n = -1)
	year<-if (is.null(year$Tmean)) data.frame(year=NA,Tmean=NA,Tmin=NA,Tmax=NA) else year
	
	#make hydrologic year
    hyear<-NULL
    for (y in 1990:2010) {
    	dbs<-""&round(y,0)&"-10-01"
		des<-""&round(y+1,0)&"-10-01"
	    QueryString <- "SELECT year(DBtime) AS year, COUNT(Tmean) AS count, "&
		   	           "AVG(Tmean) AS Tmean, MIN(Tmin) as Tmin, MAX(Tmax) AS Tmax "&
		    	       "FROM R_temp_table_day WHERE count >= "&round(qday,0)&
			           " AND DBtime >= DATE('"&dbs&"') AND DBtime <DATE('"&des&"')"
		#send query to execute on db server
		res <- dbSendQuery(db, QueryString)  
		tmp <- fetch(res, n = -1)
		#if (tmp$count < qann) {tmp$Tmean<-NA}
		tmp$year<-y
		#hyear <- rbind(hyear,tmp)
	    hyear<-if (tmp$count < qann) rbind(hyear,data.frame(year=y,count=0,Tmean=NA,Tmin=NA,Tmax=NA)) else rbind(hyear,tmp)
    }
	hyear<-if (is.null(hyear$Tmean)) data.frame(year=NA,Tmean=NA,Tmin=NA,Tmax=NA) else hyear
	
	#disconnect from db server
    dbDisconnect(db)
    
    #make proper R time
    time_hour <- strptime(hour$DBtime, format="%Y-%m-%d %H:%M:%OS")
    time_day  <- strptime(day$DBtime,  format="%Y-%m-%d %H:%M:%OS")    
    
    #combine into data frames   
    hourly <- data.frame(time=if (is.null(time_hour))  NA else time_hour,
                        Tmean=if (is.null(hour$Tmean)) NA else hour$Tmean,
                         Tmin=if (is.null(hour$Tmin))  NA else hour$Tmin,
                         Tmax=if (is.null(hour$Tmax))  NA else hour$Tmax,
                        count=if (is.null(hour$count)) NA else hour$count)
    daily  <- data.frame(time=if (is.null(time_day))   NA else time_day,
                        Tmean=if (is.null(day$Tmean))  NA else day$Tmean,
                         Tmin=if (is.null(day$Tmin))   NA else day$Tmin,
                         Tmax=if (is.null(day$Tmax))   NA else day$Tmax,
                        count=if (is.null(day$count))  NA else day$count)
                            
    #combine results into list
    result<-list(hourly=hourly,daily=daily,annual=year, hyear=hyear)
        
    #return result
    return(result)
	}

	
	
#=== PLOT ALL PERMOS LOGGERS DAILY ====================================
	gst.db.plot.PERMOS.all <-function(file)   {
		list<-c("CH_0033","CH_0024","CH_0032","CH_0018","CH_0035","CH_0003",
				"CH_0011","CH_0005","CH_0022","CH_0031","CH_0034","CH_0001",
				"CH_0002","CH_0006","CH_0010","CH_0016","CH_0004","CH_0008",
				"CH_0009","CH_0015","CH_0012","CH_0007","CH_0013","CH_0019",
				"CH_0021","CH_0023","CH_0026","CH_0027","CH_0029","CH_0020",
				"CH_0028","CH_0017","CH_0014","CH_0030","CH_0025")
		
		pdf(file=file,11,8)
		par(mfrow=c(3,1)) 
		for (i in 1:length(list)) {
			data<-gst.db.aggregate(list[i], 12, 360)
			plot(data$daily$time,data$daily$Tmean, main=list[i])
		}
		dev.off()
	}	
	
	
	

#=== EXPORT HOURLY, DAILY AND ANNUAL TIME AGGREGATE FROM DB ==========
gst.db.export.PERMOS <-function(site_ID,path) {
   qann <- 360  #minimum number of full days of measurements per year
   qday <- 12   #minimum number of full hours of measurements per 	
   #get data
   print(site_ID)
   db <- gst.db.aggregate(site_ID,qday,qann)
      
   #write hourly data without data gps (NAs)
   time <- format(db$hourly$time,format="%d.%m.%Y %H:%M")
   temp <- round(db$hourly$Tmean,2)
   write.table(data.frame(Date=time,temp=temp),col.names = c("Date","0.1"),
             file=path&site_ID&"_hourly.csv",sep=",",dec=".",
             row.names = FALSE,quote = FALSE)
             
   #write daily data without data gps (NAs)
   time <- format(db$daily$time,format="%d.%m.%Y")
   temp <- round(db$daily$Tmean,2)
   write.table(data.frame(Date=time,temp=temp),col.names = c("Date","0.1"),
             file=path&site_ID&"_daily.csv",sep=",",dec=".",
             row.names = FALSE,quote = FALSE)   
                     
   #write annual data without data gps (NAs)
   time <- db$annual$year
   temp <- round(db$annual$Tmean,2)
   write.table(data.frame(Date=time,temp=temp),col.names = c("Date","0.1"),
             file=path&site_ID&"_annual.csv",sep=",",dec=".",
             row.names = FALSE,quote = FALSE) 
	 
    #write annual data without data gps (NAs)
	time <- db$hyear$year
	temp <- round(db$hyear$Tmean,2)
	write.table(data.frame(Date=time,temp=temp),col.names = c("Date","0.1"),
			file=path&site_ID&"_annual_hydrologic.csv",sep=",",dec=".",
			row.names = FALSE,quote = FALSE) 
	 
   }

	
#=== EXPORT ALL PERMOS LOGGERS DB ====================================
gst.db.export.PERMOS.all <-function(path)   {
   list<-c("CH_0033","CH_0024","CH_0032","CH_0018","CH_0035","CH_0003",
		   "CH_0011","CH_0005","CH_0022","CH_0031","CH_0034","CH_0001",
		   "CH_0002","CH_0006","CH_0010","CH_0016","CH_0004","CH_0008",
		   "CH_0009","CH_0015","CH_0012","CH_0007","CH_0013","CH_0019",
		   "CH_0021","CH_0023","CH_0026","CH_0027","CH_0029","CH_0020",
		   "CH_0028","CH_0017","CH_0014","CH_0030","CH_0025")
   for (i in 1:length(list)) {
	   gst.db.export.PERMOS(list[i],path)
   }
}

gst.db.export.PermaNET.all <-function(path)   {
list<-c("DE_0001","DE_0002","DE_0003","DE_0004","DE_0005",#"DE_0006",
	   "DE_0007","DE_0008","DE_0009","DE_0010","DE_0011","DE_0012")
   for (i in 1:length(list)) {
	   gst.db.export.PERMOS(list[i],path)
   }
}

#=== MAKE SUMMARY TABLE ALL PERMOS LOGGERS DB =========================
gst.db.table.PERMOS.all <-function(path)   {
	list<-c("CH_0033","CH_0024","CH_0032","CH_0018","CH_0035","CH_0003",
			"CH_0011","CH_0005","CH_0022","CH_0031","CH_0034","CH_0001",
			"CH_0002","CH_0006","CH_0010","CH_0016","CH_0004","CH_0008",
			"CH_0009","CH_0015","CH_0012","CH_0007","CH_0013","CH_0019",
			"CH_0021","CH_0023","CH_0026","CH_0027","CH_0029","CH_0020",
			"CH_0028","CH_0017","CH_0014","CH_0030","CH_0025")
	#make data frame dummy
	table<-NULL
	for (i in 1:length(list)) {
		meta<-read.rst.meta(list[i])
		data<-gst.db.aggregate(list[i],12,360)
		print(meta$site_ID)
		table<-rbind(table, data.frame(Code=meta$site_ID,
									   Name=meta$site_name,
									   Responsible="UZH",
									   Coordinates=paste(meta$x,"/",meta$y,sep = ""),
			                           Elevation=meta$ele,
									   Slope=meta$slp,
									   Aspect=meta$asp,
									   Skyview=meta$sky,
									   MAGT0607=round(data$hyear$Tmean[data$hyear$year==2006],2),
									   MAGT0708=round(data$hyear$Tmean[data$hyear$year==2007],2)))
	}
	return(table)
}

   
#==== READ OLD IDL FILE ==============================================
idl.julday.as.posix <-function(julday) {
	#JULDAY(1, 1, 2000, 0, 0, 0) = 2451544.5
	time<-strptime("01.01.2000 00:00", format="%d.%m.%Y %H:%M")+(julday-2451544.5)*86400
	return(time)
	}

gst.IDL.read <-function(path,site_ID) {
	#make file name
	filename<-path&site_ID&".asc_raw"
	#read file
    raw<-read.table(filename, skip=12,header=FALSE,sep="")    
    temperature<-raw[,11]
    time<-idl.julday.as.posix(raw[,2])
	raw<-data.frame(time=time,temperature=temperature,site_ID=rep(site_ID,length(temperature)))
	
	#feedback on dates
	print("End of IDL: "&max(time))
	#connect to db server
	db <- gst.db.con()
	#query for beg/end
	sql_select<-"SELECT min(time) AS begin, max(time) AS end FROM rockt_10cm WHERE site_ID = '"&site_ID&"'" 
	beg <- dbGetQuery(db, sql_select)
	print("Beg of DB:  "&beg$begin)
	#catch non-existing site in DB
	if (is.na(beg$begin) == TRUE) {
		beg$begin<-max(time)+10000
		beg$end<-max(time)
		dbp<-0
	} else {
		dbp<-1
		sql_select<-"SELECT time, temperature FROM rockt_10cm WHERE site_ID = '"&site_ID&"'" 
		dbval <- dbGetQuery(db, sql_select)
		rtime<-strptime(dbval$time, format="%Y-%m-%d %H:%M:%OS")
	}
	#disconnect from db server
	dbDisconnect(db)
	
	#cut
	dbcut<-strptime(beg$begin, format="%Y-%m-%d %H:%M:%OS")
	cut<-subset(raw,time < dbcut)
	
	#plot for checking
	main<-"Site:"&site_ID&": green: cut IDL, black: db"
	plot(raw$time,raw$temperature, type="l",col=2, main=main)
	abline(v=dbcut)
	if (dbp == 1) {lines(rtime, dbval$temperature, col=1)}
	lines(cut$time, cut$temperature, col=3,lwd=0.5)
	print("End of cut: "&max(cut$time))
	
    #return result
    return(cut)
	}	
	
#==== INSERT IDL FILE INTO DB ========================================
insert.db.rst.idl<-function(path,site_ID,commit) {
	if (commit == TRUE) {
		gst.db.insert(gst.IDL.read(path,site_ID))
	} else {
		tmp<-gst.IDL.read(path,site_ID)				
	}}		
	

#==== READ GEOPRECISION FILE =========================================
read.rst<-function(filename,site_ID,cut_beg,cut_end) {
	#set flag for logger recognition
	log<-"unknown"
	
	#read file and detect type
	raw<-readLines(filename)
	if (substr(raw[1],1,6)  == "M-Log1") {log<-"Mlog 1 - IR2"}
	if (substr(raw[1],1,28) == "Data Logger - Serial Number:") {log<-"Mlog 1 - IR1"}
	if (substr(raw[1],1,9)  == "Logger: #") {log<-"Mlog wireless"}
	
	print("Datalogger type: " & log)
	
	#terminate if logger is unknown
	if (log == "unknown") {
		return()
	} else {
		#continue if logger is detected	
		if (log == "Mlog 1 - IR2") {
			#detect decimal sign
			if (grepl(",",raw[3]) == TRUE) {dec=","} else {dec="."}
			raw<-read.csv(filename, sep="", header = FALSE, dec=dec, skip=2)
			datetime <- strptime(paste(raw$V2, raw$V3, sep = " "), format="%d.%m.%Y %H:%M")
			raw<-data.frame(datetime=datetime,temperature=raw$V4,site_ID=rep(site_ID,length(raw$V1)))
		}
		if (log == "Mlog 1 - IR1") {
			raw<-read.csv(filename, sep=",", header = FALSE, dec=".", skip=4)
			datetime <- strptime(raw$V2, format="%d.%m.%Y %H:%M:%S")
			raw<-data.frame(datetime=datetime,temperature=raw$V3,site_ID=rep(site_ID,length(raw$V1)))
		}			
		if (log == "Mlog wireless") {
			raw<-read.csv(filename, sep=",", header = FALSE, dec=".", skip=2)
			datetime <- strptime(raw$V2, format="%d.%m.%Y %H:%M:%S")
			raw<-data.frame(datetime=datetime,temperature=raw$V3,site_ID=rep(site_ID,length(raw$V1)))
		}	
		
		
	}
	
	#drop NA
	raw<-na.omit(raw)
	
	#cut time series
	if (exists("cut_beg",mode="numeric") == FALSE) {cut_beg<-0} #assign value if not set
	if (exists("cut_end",mode="numeric") == FALSE) {cut_end<-0} #assign value if not set
	dbeg<-min(raw$datetime)
	dend<-max(raw$datetime)
	dcut_beg<-dbeg+cut_beg*86400 #date to trim
	dcut_end<-dend-cut_end*86400 #date to trim	
	cut<-subset(raw,(datetime >= dcut_beg) & (datetime <= dcut_end))
	
	#plot cut and raw time series
	layout(matrix(c(1,1,2,3), 2, 2, byrow = TRUE))
	sub<-"File: "&filename&" -- trimming: ["&round(cut_beg,2)&";"&round(cut_end,2)&"] days."
	plot(raw$datetime,raw$temperature, type="l",col=2, lwd=0.8, main=site_ID&": entire data series", sub=sub, xlab="")
	lines(cut$datetime, cut$temperature, col=1, lwd=1.2)
	abline(v=dcut_beg)
	abline(v=dcut_end)
	
	plot(raw$datetime,raw$temperature, type="l",col=2, lwd=0.8,xlim=c(dbeg,dbeg+86400*7), main="Trimming at beginning",xaxt="n", xlab="")
	axis.POSIXct(1, at=seq(dbeg,dbeg+86400*7, by=86400*2), format="%d.%m") #label the x axis by days
	lines(cut$datetime, cut$temperature, col=1, lwd=1.2)
	abline(v=dcut_beg)
	
	plot(raw$datetime,raw$temperature, type="l",col=2, lwd=0.8,xlim=c(dend-86400*7,dend), main="Trimming at end",xaxt="n", xlab="")
	axis.POSIXct(1, at=seq(dend-86400*7,dend, by=86400*2), format="%d.%m") #label the x axis by days
	lines(cut$datetime, cut$temperature, col=1, lwd=1.2)
	abline(v=dcut_end)
	
	#return result
	return(cut)
}




#==== READ RST .META FILES ===========================================
# small update jn, mar 2011: read metadata as character and numbers not factors

meta.get.val <- function(raw, label) {
	#get length
	len<-length(raw)
	#loop over lines
	for (l in 1:len){
		#only process lines with "=" sign
		if (grepl("=",raw[l]) == TRUE) {
			myline=unlist(strsplit(raw[l],"=",fixed=TRUE))
			if (toupper(label) == toupper(trim(myline[1]))) {
				return(trim(myline[2]))		
		    }
	    }	
	}
	return(NA)	
}
read.rst.meta<-function(site_ID,path="/Volumes/group/permos/data/gst/rockt/doc/metadata/") {	
	require("gregmisc")
	#make filename
	#path<-"/Volumes/group/permos/data/gst/rockt/doc/metadata/"
    filename<-path&site_ID&".meta"
	
	#read file and detect type
	raw<-readLines(filename)

    #get data into data frame
	data<-data.frame(site_name=meta.get.val(raw, "SITE NAME"),
					 site_ID  =meta.get.val(raw, "SITE CODE"), 
					 area     =meta.get.val(raw, "AREA"), 
					 resp     =meta.get.val(raw, "RESPONSIBLE"), 
					 lat      =as.numeric(meta.get.val(raw, "LATITUDE")), 
					 lon      =as.numeric(meta.get.val(raw, "LONGITUDE")), 
					 x        =as.numeric(meta.get.val(raw, "X-COORDINATE")), 
					 y        =as.numeric(meta.get.val(raw, "Y-COORDINATE")), 
					 ele      =as.numeric(meta.get.val(raw, "ELEVATION")), 
					 slp      =as.numeric(meta.get.val(raw, "SLOPE")), 
					 asp      =as.numeric(meta.get.val(raw, "ASPECT")), 
					 sky      =as.numeric(meta.get.val(raw, "SKY VIEW")), 
					 hfile    =meta.get.val(raw, "HORIZON FILE"), 
					 alb      =as.numeric(meta.get.val(raw, "ALBEDO")), 
					 emi      =as.numeric(meta.get.val(raw, "EMISSIVITY")), 
					 rtype    =meta.get.val(raw, "ROCK TYPE"), 
					 k        =as.numeric(meta.get.val(raw, "THERMAL COND")), 
					 c        =as.numeric(meta.get.val(raw, "HEAT CAPACITY")), 
					 por      =meta.get.val(raw, "POROSITY"),
					 stringsAsFactors=F)
	#return data frame
	return(data)
	}

	
	

#==== INSERT GEOPRECISION FILE INTO DB ===============================
insert.db.rst<-function(filename,site_ID,cut_beg,cut_end,commit) {
if (commit == TRUE) {
	gst.db.insert(read.rst(filename,site_ID,cut_beg,cut_end))
} else {
	tmp<-read.rst(filename,site_ID,cut_beg,cut_end)				
}}		

	
#==== SUMMARIZE ANNUAL FLUCTUATIONS ==================================
permos.rst.diff.maat<-function(ele,val) {
	#CORVATSCH
	Hmet <-3305
	Tmet <--6.0	
	
	#Jungfraujoch
	Hmet <-3580
	Tmet <--7.9
	
	lapse<--0.0065
	#MAAT at site elevation
	maat<-Tmet+(ele-Hmet)*lapse
	#return result
	return(val-maat)
}
permos.rst.diff.group<-function(ID_list) {
	#process several loggers
	res<-NULL
	for (i in 1:length(ID_list)) {
		print(ID_list[i])
		meta<-read.rst.meta(ID_list[i])
		qday<-12
		if (substr(ID_list[i],1,2) == "AI") qday<-1 #daily data from MeteoSwiss
		if (substr(ID_list[i],1,2) == "BH") qday<-1 #daily data from boreholes
		tmp<-gst.db.aggregate(ID_list[i],qday,360)	
		diff<-c(NA,tmp$hyear$Tmean[2:21]-tmp$hyear$Tmean[1:20])
		diff_maat<-permos.rst.diff.maat(meta$ele,tmp$hyear$Tmean)
		if (i==1) {
			res<-data.frame(year=tmp$hyear$year,V1=diff)
			res_maat<-data.frame(year=tmp$hyear$year,V1=diff_maat)
		} else{	
			res<-cbind(res,diff)
			res_maat<-cbind(res_maat,diff_maat)
		}
	}	
	#make pretty names
	names(res)     <-(c("diff_year",ID_list))
	names(res_maat)<-(c("diff_maat",ID_list))
	#return results
	return(list(year=res,maat=res_maat))
}
permos.rst.annual<-function() {
	#list of logger in steep faces (RF)
	lface<-c("CH_0033","CH_0024","CH_0032","CH_0018","CH_0035","CH_0003",
	 	     "CH_0011","CH_0005","CH_0022","CH_0031","CH_0034","CH_0001",
		     "CH_0002","CH_0006","CH_0010","CH_0016","CH_0004","CH_0008",
		     "CH_0009","CH_0015","CH_0012")
	#rock with snow (RS)
	lsnow<-c("CH_0007","CH_0013","CH_0019","CH_0021","CH_0023","CH_0026",
		     "CH_0027","CH_0029","CH_0020","CH_0028","CH_0017","CH_0014",
		     "CH_0030","CH_0025")
	 
	#air temperature (AT) 
    lair <-c("AIRT_COV","AIRT_JUN") 	
	
	#Rock Crest (CR)  Boeholes
	lcrest <-c("BH_MAT","BH_SCH","BH_STO","BH_TSA") 
	
	#Talus/Scree Slope (TS)
	ltalus <-c("BH_FLU","BH_GEN","BH_LAP","BH_MBP") 
	
    #Rock Glacier (RG)
	lrockgl <-c("BH_MCO","BH_MUR","BH_SBE") 
	
	
	#process air temperature
	air<-permos.rst.diff.group(lair)
	
	#process crest boreholes
	crest<-permos.rst.diff.group(lcrest)
	
	#process talus boreholes
	talus<-permos.rst.diff.group(ltalus)
	
	#process crest boreholes
	rockgl<-permos.rst.diff.group(lrockgl)
	
	#process snow loggers
	snow<-permos.rst.diff.group(lsnow)

	#process face loggers
    face<-permos.rst.diff.group(lface)
	
	result<-list(snow=snow,face=face,air=air,crest=crest,talus=talus,rockgl=rockgl)
	
	#year refers to new year given the change to its previous year
    #(i.e. 2008 (hydrologoc year 2008/2009) was 0.5° warmer than the year before)
	return(result)
}					
	

#==== PLOT ANNUAL FLUCTUATIONS ==================================
plot.rst.annual2<-function(a,all) {

	plot(a$air$maat$diff_maat,a$air$maat$AIRT_COV,ylim=c(-1,10),xlim=c(1995.4,2011.4),
			type="o", pch=24, col="red",lty=0,xaxt = "n",
			main="A) Temperature relative to MAAT 1961-1990",ylab="Temperature difference [C]",xlab="Begin of hydrologic year")	
	axis(1,at=c(1995:2011),labels=1995:2011)
	abline(v=1994.5:2011.5,col="lightgrey")
	lines(a$air$maat$diff_maat,a$air$maat$AIRT_JUN,
			type="o", pch=24, col="red",lty=0)
	
	d<-0.1
	if (all == TRUE) {	
		for (i in 2:length(a$crest$maat[1,])) lines(a$crest$maat$diff_maat-d,a$crest$maat[,i],
					type="o", pch=1, col="darkgoldenrod2",lty=0,lwd=2)
		for (i in 2:length(a$talus$maat[1,])) lines(a$talus$maat$diff_maat-d*2,a$talus$maat[,i],
					type="o", pch=1, col="darkorange3",lty=0,lwd=2)
		for (i in 2:length(a$rockgl$maat[1,])) lines(a$rockgl$maat$diff_maat-d*3,a$rockgl$maat[,i],
					type="o", pch=1, col="darkred",lty=0,lwd=2)	
		for (i in 2:length(a$imis$maat[1,])) lines(a$imis$maat$diff_maat-d*4,a$imis$maat[,i],
					type="o", pch=1, col="darkgreen",lty=0,lwd=2)	
	}
	for (i in 2:length(a$snow$maat[1,])) lines(a$snow$maat$diff_maat+d*2,a$snow$maat[,i],
				type="o", pch=23, col="cornflowerblue",lty=0)
	#for (i in 2:length(a$face$maat[1,])) lines(a$face$maat$diff_maat+d*3,a$face$maat[,i],
	#			type="o", pch=23, col="chartreuse4",lty=0)
	
	if (all == TRUE) {	
		#legend
		legend("topleft", legend= c("AirT COV/JUN","BH-rockgl","BH-talus","BH-crest","RST-face","RST-snow", "imis"), cex=0.8, 
					  col=c("red","darkred","darkorange3","darkgoldenrod2","chartreuse4","cornflowerblue","darkgreen"), 
					  lwd=c(1,3,3,3,2,0.8), 
					  pch=c(24,1,1,1,23,23,1),
				  	  lty=rep(0,6),bg="white")
	} else {
		#legend
		legend(2001, 12, c("AirT COV/JUN","RST-face","RST-snow"), cex=0.8, 
				col=c("azure4","chartreuse4","cornflowerblue"), 
				lwd=c(4,2,1), 
				pch=c(24,23,23),
				lty=rep(0,6),bg="white")	
	}		
	abline(h=0,col="red")
}


#==== PLOT ANNUAL FLUCTUATIONS ==================================
plot.rst.annual2<-function(a,all) {

	plot(a$air$maat$diff_maat,a$air$maat$AIRT_COV,ylim=c(0,10),xlim=c(2004.8,2007.2),
			type="o", pch=24, col="red",lty=0,xaxt = "n",
			main="A) Temperature relative to MAAT 1961-1990",ylab="Temperature difference [C]",xlab="Begin of hydrologic year")	
	axis(1,at=c(2005,2006,2007),labels=c(2005,2006,2007))
	lines(a$air$maat$diff_maat,a$air$maat$AIRT_JUN,
			type="o", pch=24, col="red",lty=0)
	
	d<-0.1
	if (all == TRUE) {	
		for (i in 2:length(a$crest$maat[1,])) lines(a$crest$maat$diff_maat-d,a$crest$maat[,i],
					type="o", pch=19, col="darkgoldenrod2",lty=0)
		for (i in 2:length(a$talus$maat[1,])) lines(a$talus$maat$diff_maat-d*2,a$talus$maat[,i],
					type="o", pch=19, col="darkorange3",lty=0)
		for (i in 2:length(a$rockgl$maat[1,])) lines(a$rockgl$maat$diff_maat-d*3,a$rockgl$maat[,i],
					type="o", pch=19, col="darkred",lty=0)	
	}
	for (i in 2:length(a$snow$maat[1,])) lines(a$snow$maat$diff_maat+d,a$snow$maat[,i],
				type="o", pch=23, col="cornflowerblue",lty=0)
	for (i in 2:length(a$face$maat[1,])) lines(a$face$maat$diff_maat-d,a$face$maat[,i],
				type="o", pch=23, col="chartreuse4",lty=0)
	
	if (all == TRUE) {	
		#legend
		legend(2001, 12, c("AirT COV/JUN","BH-rockgl","BH-talus","BH-crest","RST-face","RST-snow"), cex=0.8, 
					  col=c("azure4","darkred","darkorange3","darkgoldenrod2","chartreuse4","cornflowerblue"), 
					  lwd=c(4,3,3,3,2,0.8), 
					  pch=c(24,19,19,19,23,23),
				  	  lty=rep(0,6),bg="white")
	} else {
		#legend
		legend(2001, 12, c("AirT COV/JUN","RST-face","RST-snow"), cex=0.8, 
				col=c("azure4","chartreuse4","cornflowerblue"), 
				lwd=c(4,2,1), 
				pch=c(24,23,23),
				lty=rep(0,6),bg="white")	
	}		
	abline(h=0,col="red")
}

#==== PLOT ANNUAL FLUCTUATIONS ==================================
plot.rst.annual1<-function(a,all) {
	plot(a$air$year$diff_year,a$air$year$AIRT_COV,ylim=c(-3,3),xlim=c(2004.8,2007.2),
			type="o", pch=24, col="red",lty=0,xaxt="n",
			main="B) Temperature relative to previous year",ylab="Temperature difference [C]",xlab="Begin of hydrologic year")	
	axis(1,at=c(2005,2006,2007),labels=c(2005,2006,2007))
	lines(a$air$year$diff_year,a$air$year$AIRT_JUN,
			type="o", pch=24, col="red",lty=0)
	d<-0.1
	if (all == TRUE) {
		for (i in 2:length(a$crest$year[1,])) lines(a$crest$year$diff_year-d,a$crest$year[,i],
					type="o", pch=19, col="darkgoldenrod2",lty=0)
		for (i in 2:length(a$talus$year[1,])) lines(a$talus$year$diff_year-d*2,a$talus$year[,i],
					type="o", pch=19, col="darkorange3",lty=0)
		for (i in 2:length(a$rockgl$year[1,])) lines(a$rockgl$year$diff_year-d*3,a$rockgl$year[,i],
					type="o", pch=19, col="darkred",lty=0)	
	}
	for (i in 2:length(a$snow$year[1,])) lines(a$snow$year$diff_year+d,a$snow$year[,i],
				type="o", pch=23, col="cornflowerblue",lty=0)
	for (i in 2:length(a$face$year[1,])) lines(a$face$year$diff_year-d,a$face$year[,i],
				type="o", pch=23, col="chartreuse4",lty=0)
	
	abline(h=0)
}

#==== PLOT ANNUAL FLUCTUATIONS ==================================
plot.rst.annual<-function(data,all) {
	par(mfcol=c(2,1))  
	plot.rst.annual2(data,all)
	plot.rst.annual1(data,all)	
}




	