# =============================================================================
#'
#' @title shift
#'
#' @description Shifts elements of 2D arrays by any number of elements. 
#'
#' @details Positive are to the right while left shifts are expressed as a
#'          negative number. All shifts are circular. Elements shifted off one
#'          end wrap around and are shifted onto the other end. This function
#'          mimicks the behaviour of SHIFT in IDL. 
#'
#' @param arr Input array (2D) to be shifted.  
#' @param shift.row Number of rows to shift by.
#"                  Can be zero, positive to the right
#' @param shift.col Number of cols to shift by.
#"                  Can be zero, positive downwards.
#' 
#' @return Returns input array with its elements shifted by the desired amount.   
#' 
#' @export
#' @examples
#' arr <- array(1:9, dim = c(3, 3))
#' shift(arr, -1, 0)
#' 
#' @author Stephan Gruber <stephan.gruber@@carleton.ca>
#'
# =============================================================================
shift <- function(arr, shift.row, shift.col) {
  #function to shift an array	
  d <- dim(arr)
  ir <- im(nrow(arr), -shift.row) # row index
  ic <- im(ncol(arr), -shift.col) # col index
  arr <- arr[ir,ic]
  dim(arr) <- d
  return(arr)	
}

im <- function(index.length, offset) {
  #shift an array index by a defined offset and 
  #wrap around the other end, modulo arithmetic
  #positive number shifts in a way that elment 2 is
  #where element 1 used to be. 
  return((((1:index.length)-1+offset) %% index.length)+1)
}